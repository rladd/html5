
   function drawShape(canvasName){

      // get the canvas element using the DOM
      var canvas = document.getElementById(canvasName);

      // Make sure we don't execute when canvas isn't supported
      if (canvas.getContext){

         // use getContext to use the canvas for drawing
         var ctx = canvas.getContext('2d');

         for (i=0;i<10;i++){
            ctx.lineWidth = 1+i;
            ctx.beginPath();
            ctx.moveTo(5+i*14,5);
            ctx.lineTo(5+i*14,140);
            ctx.stroke();
         }

      }
      else {
       alert('You need Safari or Firefox 1.5+ to see this demo.');
      }
   }

