//The Particle class
function Particle(){

      //particle position
      this.x = 0;
      this.y = 0;

      //particle velocity
      this.vx = 0;
      this.vy = 0;

      this.time = 0; //the time elapsed since the particle was created
      this.life = 0; //the amount of time the particle is going to live
      this.color = "#000000";

      this.setValues = function(x, y, vx, vy){
         this.x=x; this.y=y;
         this.vx=vx; this.vy=vy;
         this.time=0;
         this.life = Math.floor(Math.random()*500);
      }

      this.setColor = function(color){
         this.color = color;
      }

      // Renders the particle using the canvas element
      this.render = function(){
         ctx.save();
         ctx.fillStyle = this.color;
         ctx.translate(this.x, this.y);
         ctx.beginPath();
         ctx.arc(0,0,10,0,Math.PI*2,true); // draw a circle
         ctx.fill();
         ctx.restore();
      }

}
