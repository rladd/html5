<!DOCTYPE HTML>
<html>
<head>
<script src="javascript/canvasLine.js" type="text/javascript"></script>
</head>
<body onload="drawShape('canvasLine');">
<canvas id="canvasLine"></canvas>
</body>
</html>
