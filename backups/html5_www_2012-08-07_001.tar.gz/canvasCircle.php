<!DOCTYPE HTML>
<html>
<head>
<script src="javascript/canvasCircle.js" type="text/javascript"></script>
</head>
<body onload="drawCircle('canvasCircle');">
<canvas id="canvasCircle" width="578" height="200"></canvas>
</body>
</html>

