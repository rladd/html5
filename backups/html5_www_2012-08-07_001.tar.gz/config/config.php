<?php

# Database Connection Settings
$config['mysql']['server']    = "localhost";
$config['mysql']['database']  = "html5";
$config['mysql']['username']  = "html5";
$config['mysql']['password']  = "html5";


?>
